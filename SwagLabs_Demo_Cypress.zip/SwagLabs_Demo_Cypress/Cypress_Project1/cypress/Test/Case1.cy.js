//const { expect } = require("chai");
//const utils = require('my_utils');
///<reference types="cypress" />
///// <reference types="cypress-xpath" />
describe("TestSuit1",()=>{
  
  it("Test Case 1",()=>{
  
          var Product_Name= "abc"
        
          cy.visit("https://www.saucedemo.com/")
          cy.get('[data-test="username"]').click()
          cy.get('[data-test="username"]').type('standard_user')
          cy.get('[data-test="password"]').click()
          cy.get('[data-test="password"]').type('secret_sauce')
          cy.get('[data-test="login-button"]').click()
          cy.wait(2000)
          cy.get('#item_3_title_link > .inventory_item_name').scrollIntoView();
          cy.get('#item_3_title_link > .inventory_item_name').invoke('text').then(text =>{
              Product_Name = text
              cy.log(Product_Name)
          cy.get(':nth-child(6) > .inventory_item_description > .pricebar > .inventory_item_price').invoke('text').then(Price =>{
                  let Product_Price = Price
                  Product_Price = Product_Price.replace('$','')
                  cy.log(Product_Price)
         // cy.get('[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]').click()
          cy.get('[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]').click()
          cy.get('.shopping_cart_link').scrollIntoView();
          //cy.wait(5000)
          cy.get('.shopping_cart_badge').should('contain', '1')
          cy.get('.shopping_cart_link').click()
          cy.get('.inventory_item_name').should('contain', Product_Name)
          cy.get('.inventory_item_price').should('contain', Product_Price)
          cy.get('[data-test="checkout"]').click()
          cy.get('[data-test="firstName"]').type('Jon')
          cy.get('[data-test="lastName"]').type('Snow')
          cy.get('[data-test="postalCode"]').type('14589625')
          cy.get('[data-test="continue"]').click()
          cy.get('.summary_info > :nth-child(2)').should('contain.text','SauceCard #')
          cy.get('.summary_info > :nth-child(4)').should('contain','FREE PONY EXPRESS DELIVERY!')
          /*cy.get('.summary_subtotal_label').invoke('text').invoke('replace','Item total: $','').then(Product_value1 => {
          let Product_value_String = Product_value1
          cy.log(Product_value_String)*/
          cy.get('.summary_tax_label').invoke('text').invoke('replace','Tax: $','').then(Tax_value1 => {
          let Tax_value_String = Tax_value1
          cy.log(Tax_value_String)
          let Product_value = Number(Product_Price)
          let Tax_value = Number(Tax_value_String)
          let Total_Price = Product_value + Tax_value
          cy.log(Total_Price)
          let Store_Doller = "$"
          Total_Price = String(Total_Price)
          cy.log(Total_Price)
          Total_Price = Store_Doller.concat("",Total_Price)
          cy.log(Total_Price)
          cy.get('[data-test="finish"]').click()
  
          //cy.title().should('eq','CHECKOUT: COMPLETE!')
          cy.get('.title').should('contain','Checkout: Complete!')
          cy.get('.complete-header').should('contain','THANK YOU FOR YOUR ORDER')
  
          })
      
  
          })
  
  
      })
          
      })
  })